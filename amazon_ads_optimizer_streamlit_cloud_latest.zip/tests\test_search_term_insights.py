import pandas as pd

from src.metric_calculator import add_core_metrics
from src.search_term_analyzer import product_group_keyword_tables, search_term_insight_tables, stem_token, term_root


SETTINGS = {
    "target_acos": 0.3,
    "break_even_acos": 0.35,
    "product_price": 25,
    "min_clicks": 8,
    "min_orders": 2,
    "min_impressions": 500,
    "brand_terms": [],
    "core_terms": [],
    "competitor_terms": [],
}


def test_ing_root_is_normalized():
    assert stem_token("running") == "run"
    assert term_root("running belt") == "running".replace("ning", "n") or term_root("running belt") == "belt"


def test_search_term_insight_tables_find_good_negative_and_clusters():
    df = pd.DataFrame(
        {
            "campaign": ["c1", "c1", "c2", "c2"],
            "ad_group": ["g1", "g1", "g2", "g2"],
            "search_term": ["charging cable", "charger cable", "bad adapter", "charging cord"],
            "impressions": [1000, 800, 900, 600],
            "clicks": [30, 10, 12, 15],
            "spend": [12.0, 9.0, 10.0, 6.0],
            "orders": [3, 0, 0, 2],
            "sales": [90.0, 0.0, 0.0, 60.0],
        }
    )
    df = add_core_metrics(df, SETTINGS)
    tables = search_term_insight_tables(df, SETTINGS)
    assert "charging cable" in set(tables["good_terms"]["search_term"])
    assert "bad adapter" in set(tables["negative_terms"]["search_term"])
    assert not tables["ad_group_clusters"].empty


def test_search_term_insight_tables_do_not_crash_when_no_good_terms():
    df = pd.DataFrame(
        {
            "search_term": ["bad adapter"],
            "impressions": [900],
            "clicks": [12],
            "spend": [10.0],
            "orders": [0],
            "sales": [0.0],
        }
    )
    df = add_core_metrics(df, SETTINGS)
    tables = search_term_insight_tables(df, SETTINGS)
    assert tables["good_terms"].empty
    assert "bad adapter" in set(tables["negative_terms"]["search_term"])


def test_product_group_keywords_merge_multiple_asins():
    df = pd.DataFrame(
        {
            "campaign": ["cat box B0AAA11111", "cat box B0BBB22222", "bird B0CCC33333"],
            "search_term": ["cat nail file", "cat nail file", "bird nesting"],
            "asin": ["B0AAA11111", "B0BBB22222", "B0CCC33333"],
            "impressions": [100, 200, 300],
            "clicks": [10, 20, 30],
            "spend": [5.0, 8.0, 12.0],
            "orders": [1, 2, 3],
            "sales": [25.0, 50.0, 90.0],
        }
    )
    df = add_core_metrics(df, SETTINGS)
    settings = dict(SETTINGS)
    settings["product_asin_groups"] = {"猫磨爪盒": ["B0AAA11111", "B0BBB22222"], "鸟毛": ["B0CCC33333"]}
    tables = product_group_keyword_tables(df, settings)
    product_terms = tables["product_group_terms"]
    merged = product_terms[(product_terms["product_group"] == "猫磨爪盒") & (product_terms["search_term"] == "cat nail file")].iloc[0]
    assert merged["clicks"] == 30
    assert merged["orders"] == 3
    assert merged["sales"] == 75.0
