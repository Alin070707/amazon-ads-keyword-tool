$ErrorActionPreference = "Continue"

$Root = Split-Path -Parent $PSScriptRoot
$Logs = Join-Path $Root "logs"
$PidFile = Join-Path $Logs "keyword_insights.pid"

if (Test-Path $PidFile) {
    $pidText = Get-Content $PidFile -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($pidText) {
        $targetProcess = Get-Process -Id ([int]$pidText) -ErrorAction SilentlyContinue
        if ($targetProcess) {
            Stop-Process -Id $targetProcess.Id -Force
            Write-Host "Stopped keyword insights process: $($targetProcess.Id)"
            Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
            exit 0
        }
    }
}

Write-Host "No running keyword insights process found."
exit 0
