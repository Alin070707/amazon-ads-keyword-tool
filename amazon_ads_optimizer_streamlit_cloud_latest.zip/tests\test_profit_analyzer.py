import pandas as pd

from src.profit_analyzer import add_profit_metrics


def test_profit_metrics_when_units_missing_uses_orders():
    df = pd.DataFrame({"orders": [2], "spend": [5.0]})
    out = add_profit_metrics(df, {"product_price": 25, "product_cost": 8})
    assert "profit_after_ads" in out.columns
    assert out.loc[0, "gross_profit_before_ads"] > 0


def test_profit_metrics_when_units_and_orders_missing_does_not_crash():
    df = pd.DataFrame({"spend": [5.0]})
    out = add_profit_metrics(df, {"product_price": 25, "product_cost": 8})
    assert out.loc[0, "gross_profit_before_ads"] == 0
    assert out.loc[0, "profit_after_ads"] == -5.0
