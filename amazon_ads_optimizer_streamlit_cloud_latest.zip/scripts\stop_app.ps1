$ErrorActionPreference = "Continue"

$Root = Split-Path -Parent $PSScriptRoot
$Logs = Join-Path $Root "logs"
$PidFile = Join-Path $Logs "streamlit.pid"

if (Test-Path $PidFile) {
    $pidText = Get-Content $PidFile -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($pidText) {
        $targetProcess = Get-Process -Id ([int]$pidText) -ErrorAction SilentlyContinue
        if ($targetProcess) {
            Stop-Process -Id $targetProcess.Id -Force
            Write-Host "Stopped app process: $($targetProcess.Id)"
            Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
            exit 0
        }
    }
}

$processes = Get-CimInstance Win32_Process | Where-Object {
    $_.CommandLine -like "*streamlit*run*app.py*"
}

if (!$processes) {
    Write-Host "No running app process found."
    exit 0
}

foreach ($p in $processes) {
    Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
    Write-Host "Stopped app process: $($p.ProcessId)"
}
