from pathlib import Path

import pandas as pd
from openpyxl import load_workbook

from src.metric_calculator import add_core_metrics
from src.report_generator import generate_excel_report
from src.rule_engine import RuleEngine


def test_excel_export(tmp_path):
    settings = {"target_acos": 0.3, "break_even_acos": 0.35, "product_price": 25, "min_clicks": 8, "min_orders": 2, "min_impressions": 500, "min_bid": 0.02, "max_bid": 8, "max_bid_down_pct": 0.3, "max_bid_up_pct": 0.2}
    df = pd.DataFrame({"campaign": ["c"], "ad_group": ["g"], "targeting": ["kw"], "impressions": [1000], "clicks": [20], "spend": [30], "orders": [1], "sales": [50], "bid": [1.0]})
    df = add_core_metrics(df, settings)
    suggestions = RuleEngine().evaluate(df, settings)
    path = generate_excel_report(df, suggestions, settings, pd.DataFrame([{"cleaned_rows": 1}]), tmp_path / "report.xlsx")
    assert Path(path).exists()
    wb = load_workbook(path)
    assert "Executive Summary" in wb.sheetnames
    assert "Bid Recommendations" in wb.sheetnames
