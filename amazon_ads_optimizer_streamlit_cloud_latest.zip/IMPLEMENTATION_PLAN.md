# Amazon Ads Optimizer Implementation Plan

## 项目架构

本项目是一个 Windows 本地运行的 Streamlit 应用，核心数据处理逻辑放在 `src/`，界面仅负责上传、参数设置、展示和导出。

- `app.py`: Streamlit 多页面入口。
- `config/`: 字段别名、报表类型、默认参数、诊断规则。
- `src/`: 文件读取、报表识别、字段映射、清洗、指标、规则、竞价、预算、广告位、利润、Excel 报告、SQLite 历史记录。
- `bulk_operations/`: Bulk Operations 草稿导出预留模块，只生成待审核草稿，不直接执行。
- `data/`: 上传、处理、导出、样例数据。
- `tests/`: 自动测试。
- `logs/`: 错误日志和运行日志。

## 数据流程

1. 用户上传 Excel 或 CSV。
2. 系统自动读取编码、工作表和数据。
3. 根据字段别名和报表特征识别报表类型。
4. 字段统一映射为标准字段。
5. 清洗数字、货币、百分比、日期、空值和重复行。
6. 合并多个文件，并保留来源文件、工作表和识别类型。
7. 计算核心广告指标、利润指标和可信度。
8. 从 YAML 读取规则并触发诊断。
9. 生成中文建议、竞价建议、预算建议、广告位建议、否定词和收割词建议。
10. 写入 SQLite 历史结果。
11. 导出多工作表 Excel 报告。

## 核心模块

- `file_loader.py`: CSV/XLSX/XLS 自动读取和异常隔离。
- `report_detector.py`: 报表类型、广告类型和日期范围识别。
- `field_mapper.py`: 中英文表头别名匹配和手动映射支持。
- `data_cleaner.py`: 字段标准化、数值转换、重复删除、数据质量报告。
- `metric_calculator.py`: CTR/CPC/CVR/ACOS/ROAS/CPA/RPC/TACOS 等指标。
- `rule_engine.py`: YAML 驱动的规则触发和中文解释生成。
- `confidence_engine.py`: 高/中/低可信度判断。
- `bid_optimizer.py`: 目标 CPC、盈亏平衡 CPC 和建议竞价。
- `budget_optimizer.py`: Campaign 预算优化建议。
- `placement_optimizer.py`: 广告位表现分析。
- `search_term_analyzer.py`: 搜索词分组、收割和否定建议。
- `profit_analyzer.py`: 毛利、广告后利润、盈亏 Campaign。
- `report_generator.py`: Excel 多工作表导出和格式化。
- `database.py`: SQLite 历史保存和读取。

## 开发阶段

1. 创建计划和目录。
2. 创建依赖、配置、启动脚本、样例数据。
3. 实现数据读取、报表识别、字段映射。
4. 实现数据清洗、核心指标和利润指标。
5. 实现 YAML 规则引擎和建议生成。
6. 实现 Streamlit 页面。
7. 实现 Excel 导出。
8. 添加自动测试。
9. 运行测试和启动验证。
10. 完成 README。

## 验收标准

- 可通过 `pip install -r requirements.txt` 安装依赖。
- 可通过 `streamlit run app.py` 或双击 bat 文件启动。
- 支持 CSV/XLSX，支持中英文表头。
- 至少识别 Sponsored Products Search Term、Targeting、Campaign 三类报表。
- 可计算核心指标并处理除零。
- 可输出 Campaign、Targeting、Search Term 分析。
- 可输出竞价、预算、否定词、搜索词收割建议。
- 可生成多工作表 Excel。
- 关键阈值和字段别名可在配置文件修改。
- 异常数据不导致整个系统崩溃。
- 自动测试通过。

## 已知风险

- 亚马逊报表字段会持续变化，第一版采用可配置别名和模糊匹配，极端新字段需要用户在界面手动映射。
- 不同站点货币和本地化数字格式可能存在歧义，第一版会尽量清洗并在数据质量报告中提示。
- Bulk Operations 模板版本差异很大，第一版只输出人工审核草稿，不声明兼容所有模板。
- 预算耗尽信息依赖报表中是否包含预算、状态或预算受限字段；字段缺失时只输出基于花费效率的预算建议。
- 业务参数默认值会影响建议，报告会标注是否使用默认参数。
