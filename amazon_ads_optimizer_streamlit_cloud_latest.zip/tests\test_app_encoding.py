from pathlib import Path


def test_app_py_does_not_contain_mojibake():
    text = Path("app.py").read_text(encoding="utf-8")
    bad_fragments = ["äº", "æŠ", "ç»", "è¯", "å¹", "ï¼", "ã€"]
    assert not any(fragment in text for fragment in bad_fragments)
    assert "亚马逊广告自动诊断与优化建议系统" in text


def test_ui_and_config_files_do_not_contain_mojibake():
    bad_fragments = ["äº", "æŠ", "ç»", "è¯", "å¹", "ï¼", "ã€"]
    for path in ["keyword_insights_app.py", "config/field_aliases.yaml", "src/search_term_analyzer.py"]:
        text = Path(path).read_text(encoding="utf-8")
        assert not any(fragment in text for fragment in bad_fragments), path
