import pandas as pd

from src.metric_calculator import add_core_metrics
from src.rule_engine import RuleEngine


SETTINGS = {
    "target_acos": 0.3,
    "break_even_acos": 0.35,
    "product_price": 25,
    "min_clicks": 8,
    "min_orders": 2,
    "min_impressions": 500,
    "min_bid": 0.02,
    "max_bid": 8,
    "max_bid_down_pct": 0.30,
    "max_bid_up_pct": 0.20,
    "brand_terms": [],
    "core_terms": [],
    "competitor_terms": [],
}


def _metrics(df):
    return add_core_metrics(df, SETTINGS)


def test_high_spend_no_orders_rule():
    df = _metrics(pd.DataFrame({"campaign": ["c"], "ad_group": ["g"], "search_term": ["bad term"], "impressions": [1000], "clicks": [12], "spend": [18], "orders": [0], "sales": [0], "bid": [1.0]}))
    out = RuleEngine().evaluate(df, SETTINGS)
    assert "高花费无订单" in set(out["diagnosis"])
    assert "Add Negative Exact" in set(out["action_type"])


def test_high_acos_rule():
    df = _metrics(pd.DataFrame({"campaign": ["c"], "ad_group": ["g"], "targeting": ["kw"], "impressions": [1000], "clicks": [20], "spend": [30], "orders": [1], "sales": [50], "bid": [1.0]}))
    out = RuleEngine().evaluate(df, SETTINGS)
    assert "ACOS明显高于目标" in set(out["diagnosis"])


def test_low_acos_scaling_rule():
    df = _metrics(pd.DataFrame({"campaign": ["c"], "ad_group": ["g"], "targeting": ["kw"], "impressions": [1000], "clicks": [20], "spend": [10], "orders": [3], "sales": [100], "bid": [1.0]}))
    out = RuleEngine().evaluate(df, SETTINGS)
    assert "低ACOS且订单稳定" in set(out["diagnosis"])


def test_search_term_harvest():
    df = _metrics(pd.DataFrame({"campaign": ["c"], "ad_group": ["g"], "search_term": ["good kw"], "impressions": [1000], "clicks": [30], "spend": [15], "orders": [3], "sales": [100], "bid": [1.0]}))
    out = RuleEngine().evaluate(df, SETTINGS)
    assert "Harvest Search Term" in set(out["action_type"])


def test_protected_core_term_is_not_negative():
    settings = dict(SETTINGS)
    settings["core_terms"] = ["core"]
    df = _metrics(pd.DataFrame({"campaign": ["c"], "ad_group": ["g"], "search_term": ["core keyword"], "impressions": [1000], "clicks": [12], "spend": [20], "orders": [0], "sales": [0], "bid": [1.0]}))
    out = RuleEngine().evaluate(df, settings)
    protected = out[out["diagnosis"].eq("高花费无订单")].iloc[0]
    assert protected["action_type"] == "Observe"
