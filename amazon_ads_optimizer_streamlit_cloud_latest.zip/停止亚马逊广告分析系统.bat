@echo off
cd /d "%~dp0"
title 停止亚马逊广告分析系统

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\stop_app.ps1"

echo.
pause
