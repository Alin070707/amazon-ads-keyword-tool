@echo off
cd /d "%~dp0"
title 停止搜索词直观分析窗口

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\stop_keyword_insights.ps1"

echo.
pause
