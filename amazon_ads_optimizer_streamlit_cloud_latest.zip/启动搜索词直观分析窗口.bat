@echo off
cd /d "%~dp0"
title 启动搜索词直观分析窗口

echo ================================================
echo          搜索词直观分析窗口
echo ================================================
echo.
echo 正在后台启动，请稍等 10-20 秒...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start_keyword_insights.ps1"

echo.
echo 如果浏览器没有自动打开，请手动访问：
echo http://127.0.0.1:8502
echo.
echo 如需关闭，请双击：
echo 停止搜索词直观分析窗口.bat
echo.
pause
