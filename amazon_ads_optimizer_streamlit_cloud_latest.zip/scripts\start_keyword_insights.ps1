$ErrorActionPreference = "Continue"

$Root = Split-Path -Parent $PSScriptRoot
$Logs = Join-Path $Root "logs"
$PidFile = Join-Path $Logs "keyword_insights.pid"
$Url = "http://127.0.0.1:8502"

if (!(Test-Path $Logs)) {
    New-Item -ItemType Directory -Path $Logs | Out-Null
}

function Test-App {
    try {
        $response = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 2
        return $response.StatusCode -eq 200
    } catch {
        return $false
    }
}

function Get-PythonPath {
    $bundled = Join-Path $env:USERPROFILE ".cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
    if (Test-Path $bundled) {
        return $bundled
    }
    $python = Get-Command python -ErrorAction SilentlyContinue
    if ($python) {
        return $python.Source
    }
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        return $py.Source
    }
    return $null
}

if (Test-App) {
    Write-Host "Keyword insights app is already running."
    Start-Process $Url
    exit 0
}

$Python = Get-PythonPath
if (!$Python) {
    Write-Host "Python was not found. Please install Python 3.11+."
    exit 1
}

$arguments = @(
    "-m", "streamlit", "run", "keyword_insights_app.py",
    "--server.address=127.0.0.1",
    "--server.port=8502",
    "--server.headless=true"
)

$process = Start-Process -FilePath $Python -ArgumentList $arguments -WorkingDirectory $Root -WindowStyle Minimized -PassThru
$process.Id | Out-File -FilePath $PidFile -Encoding ascii
Write-Host "Keyword insights app started. PID: $($process.Id)"

$ready = $false
for ($i = 1; $i -le 30; $i++) {
    Start-Sleep -Seconds 1
    if (Test-App) {
        $ready = $true
        break
    }
}

if ($ready) {
    Start-Process $Url
    exit 0
}

Write-Host "Keyword insights app start failed or timed out."
exit 1
