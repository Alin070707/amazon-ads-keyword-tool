@echo off
cd /d "%~dp0"
title 启动亚马逊广告分析系统

echo ================================================
echo      亚马逊广告自动诊断与优化建议系统
echo ================================================
echo.
echo 正在后台启动网页版，请稍等 10-20 秒...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start_app.ps1"

echo.
echo 如果浏览器没有自动打开，请手动访问：
echo http://127.0.0.1:8501
echo.
echo 如果想关闭系统，请双击：
echo 停止亚马逊广告分析系统.bat
echo.
pause
