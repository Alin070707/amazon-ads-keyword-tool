import pandas as pd

from src.metric_calculator import add_core_metrics


def test_division_by_zero_is_safe():
    df = pd.DataFrame({"impressions": [0], "clicks": [0], "spend": [0], "orders": [0], "sales": [0]})
    out = add_core_metrics(df, {"target_acos": 0.3, "break_even_acos": 0.35, "product_price": 25})
    assert out.loc[0, "ctr"] == 0
    assert out.loc[0, "cpc"] == 0
    assert out.loc[0, "acos"] == 0


def test_metrics_are_calculated():
    df = pd.DataFrame({"impressions": [100], "clicks": [10], "spend": [5], "orders": [2], "sales": [50]})
    out = add_core_metrics(df, {"target_acos": 0.3, "break_even_acos": 0.35, "product_price": 25})
    assert round(out.loc[0, "ctr"], 2) == 0.10
    assert round(out.loc[0, "cpc"], 2) == 0.50
    assert round(out.loc[0, "acos"], 2) == 0.10
    assert round(out.loc[0, "roas"], 2) == 10.00
