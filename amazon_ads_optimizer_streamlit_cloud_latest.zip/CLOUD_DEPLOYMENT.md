# 云端网页版部署说明

你朋友说的是对的：你现在打开的 `http://127.0.0.1:8502/` 或 `http://localhost:8502/` 是本地地址，只能在你自己的电脑上访问。别人要能点开，就需要把项目部署到云端，生成类似下面这样的公网网址：

```text
https://你的应用名.streamlit.app
```

## 推荐方式：Streamlit Community Cloud

这是最简单的方式，适合先给朋友、同事试用。

### 第一步：准备 GitHub 仓库

1. 打开 GitHub：`https://github.com/`
2. 注册或登录账号。
3. 点击右上角 `+`，选择 `New repository`。
4. 仓库名称可以填：

```text
amazon-ads-keyword-tool
```

5. 建议先选择 `Private`，如果只是测试也可以选 `Public`。
6. 点击 `Create repository`。
7. 把本项目文件上传到这个仓库。

建议上传这些核心文件和文件夹：

```text
app.py
keyword_insights_app.py
streamlit_app.py
requirements.txt
runtime.txt
README.md
.streamlit/
config/
src/
bulk_operations/
tests/
data/samples/
```

不要上传自己的真实广告报表，尤其是：

```text
data/uploads/
data/exports/
logs/
outputs/
```

### 第二步：创建 Streamlit Cloud 应用

1. 打开 Streamlit Cloud：`https://share.streamlit.io/`
2. 用 GitHub 账号登录。
3. 点击 `New app`。
4. 选择你刚才创建的 GitHub 仓库。
5. Branch 选择：

```text
main
```

6. Main file path 填：

```text
streamlit_app.py
```

7. 点击 `Deploy`。

部署成功后，Streamlit 会给你一个可以发给别人的链接，例如：

```text
https://amazon-ads-keyword-tool.streamlit.app
```

别人打开这个链接后，就可以上传广告报表并查看分析结果。

## 我已经帮你做好的代码调整

为了让 Streamlit Cloud 更容易启动，我已经新增了云端入口文件：

```text
streamlit_app.py
```

它默认打开“搜索词直观分析窗口”，也就是你现在最关心的这些结果：

- 哪些词表现好
- 哪些词需要否定
- 哪些词适合收割
- 哪些词属于同一个词根
- 哪些 ASIN 或产品组可以汇总看关键词
- 哪些关键词可以放到同一个广告组

## 数据安全提醒

云端版会把你上传的广告报表传到 Streamlit Cloud 的服务器上处理。第一版系统不会登录亚马逊后台，也不会自动修改广告，但报表数据本身仍然属于敏感业务数据。

如果只是自己用，建议继续用本地版。如果要发给朋友或团队用，建议先用测试数据，确认没问题后再决定是否上传真实数据。

## 如果用 Render 部署

Render 也可以部署，但比 Streamlit Cloud 稍复杂。配置如下：

Build Command：

```bash
pip install -r requirements.txt
```

Start Command：

```bash
streamlit run streamlit_app.py --server.address=0.0.0.0 --server.port=$PORT
```

本项目已经包含 `render.yaml`，后续也可以用 Render 做更稳定的服务。

