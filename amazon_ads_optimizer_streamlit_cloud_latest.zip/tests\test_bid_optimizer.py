import pandas as pd

from src.bid_optimizer import recommended_bid


def test_bid_boundaries_respected():
    row = pd.Series({"bid": 1.0, "acos": 2.0, "cpc": 1.0, "target_cpc": 0.1})
    rec = recommended_bid(row, {"target_acos": 0.3, "max_bid_down_pct": 0.30, "max_bid_up_pct": 0.20, "min_bid": 0.8, "max_bid": 1.1})
    assert rec["recommended_bid"] == 0.8


def test_bid_max_up_respected():
    row = pd.Series({"bid": 1.0, "acos": 0.1, "cpc": 0.2, "target_cpc": 1.0})
    rec = recommended_bid(row, {"target_acos": 0.3, "max_bid_down_pct": 0.30, "max_bid_up_pct": 0.20, "min_bid": 0.02, "max_bid": 8})
    assert rec["recommended_bid"] == 1.2
