from pathlib import Path

from src.data_cleaner import clean_frame
from src.field_mapper import FieldMapper
from src.file_loader import read_uploaded_file


ROOT = Path(__file__).resolve().parents[1]


def test_csv_loader_english_headers():
    tables = read_uploaded_file(ROOT / "data" / "samples" / "sp_search_term_sample_en.csv")
    assert len(tables) == 1
    assert not tables[0].frame.empty


def test_chinese_headers_are_mapped_and_cleaned():
    table = read_uploaded_file(ROOT / "data" / "samples" / "sp_targeting_sample_cn.csv")[0]
    mapped, mapping, unmapped = FieldMapper().apply_mapping(table.frame)
    assert "campaign" in mapped.columns
    assert "spend" in mapped.columns
    cleaned, quality = clean_frame(mapped)
    assert cleaned["spend"].sum() == 63.3
    assert "campaign" not in quality["missing_critical_fields"]
